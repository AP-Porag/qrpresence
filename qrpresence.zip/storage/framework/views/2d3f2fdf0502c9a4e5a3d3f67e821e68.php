<div class="page-title-box">
    <div class="row align-items-center">
        <div class="col-md-8">
            <h6 class="page-title text-capitalize"><?php echo e(get_page_meta('title', true)); ?></h6>
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="">Home</a></li>
                <li class="breadcrumb-item active text-capitalize" aria-current="page"><?php echo e(get_page_meta('title', true)); ?></li>
            </ol>
        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\qrpresence\resources\views/layouts/partials/_breadcrumb.blade.php ENDPATH**/ ?>