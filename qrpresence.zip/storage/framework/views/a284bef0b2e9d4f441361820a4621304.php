<?php $__env->startSection('content'); ?>
<div class="">
    <div class="d-flex justify-content-between">
        <h1>Student Dashboard</h1>
        <a href="<?php echo e(route('student.attendance.scan')); ?>" class="btn btn-primary pt-3">Scan Attendance</a>
    </div>
    <div class="card mt-5">
        <div class="card-body">
            <h4 class="card-title mb-3">Attendance</h4>
            <?php echo $dataTable->table(['class'=>'table-responsive']); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <?php echo $__env->make('includes.styles.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <?php echo $__env->make('includes.scripts.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\qrpresence\resources\views/admin/dashboard/student-index.blade.php ENDPATH**/ ?>