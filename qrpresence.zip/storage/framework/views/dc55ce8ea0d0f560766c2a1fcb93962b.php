<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!-- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Main</li>

                <li>
                    <a href="<?php echo e(route('home')); ?>" class="waves-effect">
                        <i class="fa fa-home"></i><span> Dashboard </span>
                    </a>
                </li>

                <li class="<?php echo e(request()->is('instructor/courses*') ? 'mm-active' : ''); ?>">
                    <a href="<?php echo e(route('instructor.courses.index')); ?>" class="waves-effect <?php echo e(request()->is('instructor/courses*') ? 'mm-active' : ''); ?>">
                        <i class="fa fa-book"></i><span> Courses </span>
                    </a>
                </li>

























            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH D:\laragon\www\qrpresence\resources\views/layouts/partials/sidebars/_sidebar-instructor.blade.php ENDPATH**/ ?>