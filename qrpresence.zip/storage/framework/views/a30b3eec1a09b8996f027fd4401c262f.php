<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.0.3/js/dataTables.buttons.min.js"></script>
<script src="/vendor/datatables/buttons.server-side.js"></script>
<?php echo $dataTable->scripts(); ?>

<?php /**PATH D:\laragon\www\qrpresence\resources\views/includes/scripts/datatable.blade.php ENDPATH**/ ?>