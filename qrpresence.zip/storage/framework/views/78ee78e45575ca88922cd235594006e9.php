<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="//cdn.datatables.net/buttons/1.0.3/css/buttons.dataTables.min.css">
<link href="<?php echo e(URL::asset('admin/css/datatable.css')); ?>" rel="stylesheet" type="text/css" />

<style>
    .dataTables_length {
        margin-left: 10px;
        padding-top: 0.5em;
    }
</style>
<?php /**PATH D:\laragon\www\qrpresence\resources\views/includes/styles/datatable.blade.php ENDPATH**/ ?>