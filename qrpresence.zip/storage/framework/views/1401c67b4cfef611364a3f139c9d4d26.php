<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!-- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Main</li>

                <li>
                    <a href="<?php echo e(route('home')); ?>" class="waves-effect">
                        <i class="fa fa-home"></i><span> Dashboard </span>
                    </a>
                </li>

                <li
                    class="<?php echo e(request()->is('admin/users*') ? 'mm-active' : ''); ?>">
                    <a href="javascript: void(0);"
                       class="has-arrow waves-effect <?php echo e(request()->is('admin/users*') ? 'mm-active' : ''); ?>">
                        <i class="fas fa-users"></i>
                        <span>Administration</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="true">
                        <li class="<?php echo e(request()->is('admin/users*') ? 'mm-active' : ''); ?>">
                            <a href="<?php echo e(route('admin.users.index')); ?>"
                               class="<?php echo e(request()->routeIs('admin.users.index') ? 'active' : ''); ?>">
                                Users
                            </a>
                        </li>
                    </ul>
                </li>






            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH D:\laragon\www\qrpresence\resources\views/layouts/partials/sidebars/_sidebar-admin.blade.php ENDPATH**/ ?>