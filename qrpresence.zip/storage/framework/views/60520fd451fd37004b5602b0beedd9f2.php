<script src="<?php echo e(asset('admin/js/admin-app.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/simplebar/simplebar.min.js')); ?>"></script>


<script src="<?php echo e(asset('admin/libs/select2/js/select2.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/js/script.js')); ?>"></script>

<!-- Parsley js -->
<script src="<?php echo e(asset('backend/js/parsley.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom-dev.js')); ?>"></script>


<script>
    toastr.options =
    {
        "closeButton": true,
        "progressBar": true,
        "timeOut": 2000
    }

    <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
    <?php if(Session::has('update')): ?>
        toastr.info("<?php echo e(session('update')); ?>");
    <?php endif; ?>
    <?php if(Session::has('delete')): ?>
    toastr.success("<?php echo e(session('delete')); ?>");
    <?php endif; ?>
    <?php if(Session::has('info')): ?>
        toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>
    <?php if(Session::has('warning')): ?>
        toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    // Toaster notify
    const notify = (type, msg) => {
        if (type == 'success') {
            toastr.success(msg);
        } else {
            toastr.warning(msg);
        }
    }

    function showValidationError(err) {
        let error_string = '<div class="error-sa-v text-left">';
        for (const [key, value] of Object.entries(
        err.response.data.errors
        )) {
            error_string = error_string + value[0] + "<br>";

            if (value[1] != "undefined" && value[1] != undefined) {
                error_string = error_string + value[1] + "<br>";
            }
        }
        error_string = error_string + "<div>";

        Swal.fire({
            icon: "error",
            html: error_string,
        });
    }

    function showSomethingWrong() {
        Swal.fire({
            icon: "error",
            html: "<span>Something is wrong!</span>" + "<br>",
            showConfirmButton: true,
        });
    }

    const uploadFileCustom = (selector, type = "image") => {
        const file = $(`.${selector}`).filemanager(`${type}`);
    }

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<?php echo $__env->yieldPushContent('script'); ?>
<?php /**PATH D:\laragon\www\qrpresence\resources\views/layouts/partials/_footer-script.blade.php ENDPATH**/ ?>