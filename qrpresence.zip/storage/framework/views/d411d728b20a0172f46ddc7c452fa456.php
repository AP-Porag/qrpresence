<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                © <?php echo e(date('Y')); ?>

            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\laragon\www\qrpresence\resources\views/layouts/partials/_footer.blade.php ENDPATH**/ ?>