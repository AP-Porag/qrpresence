<div class="page-title-box">
    <div class="row align-items-center">
        <div class="col-md-8">
            <h6 class="page-title text-capitalize">{{ get_page_meta('title', true) }}</h6>
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="">Home</a></li>
                <li class="breadcrumb-item active text-capitalize" aria-current="page">{{ get_page_meta('title', true) }}</li>
            </ol>
        </div>
    </div>
</div>
